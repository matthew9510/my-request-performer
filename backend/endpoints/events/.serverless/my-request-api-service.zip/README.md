# Events Table
* service: my-request-events-service
* stage: dev
* region: us-west-2
* stack: my-request-events-service-dev
* resources: 46
* api keys: None
* endpoints:
  POST - https://gzoi39rho8.execute-api.us-west-2.amazonaws.com/dev/events
  GET - https://gzoi39rho8.execute-api.us-west-2.amazonaws.com/dev/events
  GET - https://gzoi39rho8.execute-api.us-west-2.amazonaws.com/dev/events/{id}
  PUT - https://gzoi39rho8.execute-api.us-west-2.amazonaws.com/dev/events/{id}
  DELETE - https://gzoi39rho8.execute-api.us-west-2.amazonaws.com/dev/events/{id}
* functions:
  create: my-request-events-service-dev-create
  list: my-request-events-service-dev-list
  get: my-request-events-service-dev-get
  update: my-request-events-service-dev-update
  delete: my-request-events-service-dev-delete
* Sample Curl commands for testing:
    - curl https://gzoi39rho8.execute-api.us-west-2.amazonaws.com/dev/events
    
    
