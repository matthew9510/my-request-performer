var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'softstack',
applicationName: 'my-request',
appUid: '4XFJd9Nhtp2DRxvs4x',
orgUid: 'XWwwFN8qv8wVdD5yvZ',
deploymentUid: 'b3fcee36-ebaa-42c0-8d2a-4967f9b6d430',
serviceName: 'my-request-api-service',
stageName: 'dev',
pluginVersion: '3.3.0'})
const handlerWrapperArgs = { functionName: 'my-request-api-service-dev-list', timeout: 6}
try {
  const userHandler = require('./events/list.js')
  module.exports.handler = serverlessSDK.handler(userHandler.list, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
